package comp5216.sydney.edu.au.assignmentt;

/**
 * Created by Administrator on 2016/8/22.
 */
public class Food {
    private String name;
    private double Kilojoules;
    private double Carbohydrate;
    private double Protein;
    private double Fat;
    private double Dietary_Fiber;
    private String Description;

    public Food (){}

    public Food(String name,double kilojoules,double carbohydrate,double protein, double fat,double dietary_Fiber){
        this.name = name;
        this.Kilojoules=kilojoules;
        this.Carbohydrate=carbohydrate;
        this.Protein=protein;
        this.Fat=fat;
        this.Dietary_Fiber=dietary_Fiber;
        this.Description="";
    }

    public Food(String name,double kilojoules,double carbohydrate,double protein, double fat,double dietary_Fiber,String description){
        this.name=name;
        this.Kilojoules=kilojoules;
        this.Carbohydrate=carbohydrate;
        this.Protein=protein;
        this.Fat=fat;
        this.Dietary_Fiber=dietary_Fiber;
        this.Description=description;
    }

    public double getKilojoules() {
        return Kilojoules;
    }

    public void setKilojoules(double kilojoules) {
        Kilojoules = kilojoules;
    }

    public double getCarbohydrate() {
        return Carbohydrate;
    }

    public void setCarbohydrate(double carbohydrate) {
        Carbohydrate = carbohydrate;
    }

    public double getFat() {
        return Fat;
    }

    public void setFat(double fat) {
        Fat = fat;
    }

    public double getProtein() {
        return Protein;

    }

    public void setProtein(double protein) {
        Protein = protein;
    }

    public double getDietary_Fiber() {
        return Dietary_Fiber;
    }

    public void setDietary_Fiber(double dietary_Fiber) {
        Dietary_Fiber = dietary_Fiber;
    }

    public String getDescription() {
        return Description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        Description = description;

    }
}
