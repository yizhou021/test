package comp5216.sydney.edu.au.assignmentt;


//import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TabHost;
import android.widget.TextView;

/**
 * Created by Administrator on 2016/8/15.
 */
public class StateActivity  extends TabActivity {
    private TextView testview;
    private Button addbutton;
    private int ADD_REQUEST_CODE=222;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statelayout);
        TabHost tabHost = getTabHost();

        TabHost.TabSpec tab1 = tabHost.newTabSpec("tab1")
                .setIndicator("tab1")
                .setContent(R.id.tab1);
        tabHost.addTab(tab1);
        TabHost.TabSpec tab2 = tabHost.newTabSpec("tab2")
                .setIndicator("tab2")
                .setContent(R.id.tab2);
        tabHost.addTab(tab2);

        Intent intent = getIntent();
        Double value = intent.getDoubleExtra("total",0);
        testview = (TextView) findViewById(R.id.CalState);
        testview.setText(value+"");



        addbutton = (Button)findViewById(R.id.buttonAdd);
        addbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentadd = new Intent();
                intentadd.setClass(StateActivity.this,IngredientList.class);
                StateActivity.this.startActivityForResult(intentadd,ADD_REQUEST_CODE);
            }
        });


    }
}
