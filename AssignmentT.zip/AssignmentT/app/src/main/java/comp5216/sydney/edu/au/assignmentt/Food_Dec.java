package comp5216.sydney.edu.au.assignmentt;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Administrator on 2016/8/22.
 */
public class Food_Dec extends Activity{
    private Button calbutton;
    private TextView name, energy, carbohydrate, protein, fat, dietary_fiber, Dec;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_des);

        calbutton = (Button)findViewById(R.id.food_dec_calbut);

        name = (TextView)findViewById(R.id.foodName);
        energy = (TextView)findViewById(R.id.FD_EnergyS);
        carbohydrate = (TextView)findViewById(R.id.FD_CarS);
        protein = (TextView)findViewById(R.id.FD_ProteinS);
        fat = (TextView)findViewById(R.id.FD_FatS);
        dietary_fiber = (TextView)findViewById(R.id.FD_FiberS);
        Dec = (TextView)findViewById(R.id.FD_DecS);
        Intent data = getIntent();

        name.setText(data.getStringExtra("name"));
        energy.setText(data.getDoubleExtra("energy",0)+" Kcal");
        carbohydrate.setText(data.getDoubleExtra("carbohydrate",0)+" g");
        protein.setText(data.getDoubleExtra("protein",0)+" g");
        fat.setText(data.getDoubleExtra("fat",0)+" g");
        dietary_fiber.setText(data.getDoubleExtra("daily_fiber",0)+" g");
        Dec.setText(data.getStringExtra("dec"));
        Dec.setMovementMethod(ScrollingMovementMethod.getInstance());

        calbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
            }
        });
    }
}
