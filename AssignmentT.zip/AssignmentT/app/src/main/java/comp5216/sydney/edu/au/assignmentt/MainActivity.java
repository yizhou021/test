package comp5216.sydney.edu.au.assignmentt;

import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends Activity {
private int CALCULATE_REQUEST_CODE=111;
    private Button calbutton;
    private EditText age, weight, height;
    private RadioButton male,female,none, low, mid, lot,per;
    private double rate=0,result=0,weightD=0,heightD=0;
    private int ageD=0;
    private String weightM,heightM,ageM;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        age = (EditText)findViewById(R.id.editAge) ;
        weight = (EditText)findViewById(R.id.editWeight);
        height = (EditText)findViewById(R.id.editHeight);
        male = (RadioButton)findViewById(R.id.radioMale);
        female = (RadioButton)findViewById(R.id.radioFemale);
        none = (RadioButton)findViewById(R.id.radioNone);
        low = (RadioButton)findViewById(R.id.radioLow);
        mid = (RadioButton)findViewById(R.id.radioMid);
        lot = (RadioButton)findViewById(R.id.radioLot);
        per = (RadioButton)findViewById(R.id.radioPre);




        calbutton = (Button)findViewById(R.id.buttonCal);
        calbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                weightM = weight.getText().toString();
                heightM = height.getText().toString();
                ageM = age.getText().toString();


                weightD = convertD(weightM);
                heightD = convertD(heightM);
                ageD = convertI(ageM);

                rate = rateCheck();

                if(female.isChecked()){
                    result=rate * FemaleBMR(weightD,heightD,ageD);
                    Toast.makeText(MainActivity.this,result+"",Toast.LENGTH_SHORT).show();
                }

                else if(male.isChecked()){
                    result=rate * MaleBMR(weightD,heightD,ageD);
                    Toast.makeText(MainActivity.this,result+"",Toast.LENGTH_SHORT).show();
                }

                Intent intent = new Intent(MainActivity.this,StateActivity.class);
                intent.putExtra("total",result);
                startActivity(intent);
            }
        });

    }


    public double FemaleBMR(double weight, double height, int age){
        double BMR=655 + (9.6 * weight)+(1.8 * height)-(4.7 * age);
        return BMR;
    }

    public double MaleBMR(double weight, double height, int age){
        double BMR=66 + (13.7 * weight)+(5 * height)-(6.8 * age);
        return BMR;
    }

    public double convertD(String input){
        double output;
        if(input!=null && !input.equals("")){
            output = Double.parseDouble(input);
            return output;
        }
        else
            return 0;
    }

    public int convertI(String input){
        int output;
        if(input!=null && !input.equals("")){
            output = Integer.parseInt(input);
            return output;
        }
        else
            return 0;
    }

    public double rateCheck(){
        double rate=0;
        if(none.isChecked())
            rate = 1.2;
        else if(low.isChecked())
            rate = 1.375;
        else if(mid.isChecked())
            rate = 1.55;
        else if(lot.isChecked())
            rate = 1.725;
        else if(per.isChecked())
            rate = 1.9;
        return rate;
    }
}
