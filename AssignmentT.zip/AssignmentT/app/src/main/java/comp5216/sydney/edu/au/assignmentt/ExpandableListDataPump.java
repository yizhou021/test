package comp5216.sydney.edu.au.assignmentt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Administrator on 2016/8/16.
 */
public class ExpandableListDataPump {

    private static  HashMap<String, List<Food>> storeData(){
        HashMap<String, List<Food>> expandableListDetail = new HashMap<String, List<Food>>();
        List<Food> Carbohydrate = new ArrayList<Food>();
        Food Potato = new Food("Potato, Raw, Skin",58.0, 12.44, 2.57, 0.1, 2.5,"Vitamin C:    11.4 mg \n Calcium:    30.0 mg \n" +
                "Iron:    3.24 mg \n Magnesium:    23.0 mg \n Phosphorus:    38.0 mg \n Potassium:   413.0 mg \n Sodium:    10.0 mg \n Zinc:    0.35mg \n" +
                "Niacin:    1.033 mg \n Vitamin B-6:    0.239 mg");
        Food Rice = new Food("Rice,white,cooked",97.0, 21.09, 2.02, 0.19, 1.0,"Niacin:    0.02 mg \n Calcium:    2.0 mg \n" +
                "Iron:    0.14 mg \n Magnesium:    5.0 mg \n Phosphorus:    8.0 mg \n Potassium:    10.0 mg \n Sodium:    5.0 mg \n Zinc:    0.41mg \n" +
                "Fatty acids total \n monounsaturated:  0.07 mg \n Vitamin B-6:    0.026 mg");
        Carbohydrate.add(Potato);
        Carbohydrate.add(Rice);


        List<Food> Meat = new ArrayList<Food>();
        Food Chicken = new Food("Chicken breast,raw",120, 0, 22.5, 2.62, 0,"Niacin: 9.60 mg \n Calcium: 5.0 mg \n" +
                "Iron: 0.37 mg \n Magnesium: 28.0 mg \n Phosphorus: 213.0 mg \n Potassium: 334.0 mg \n Sodium: 45.0 mg \n Zinc: 0.68mg \n" +
                "Vitamin A, IU: 30 mg \n Vitamin B-6: 0.81 mg \n Cholesterol: 73.0mg");
        Meat.add(Chicken);

        List<Food> SeaFood = new ArrayList<Food>();


        List<Food> Vegetable = new ArrayList<Food>();


        List<Food> Fruit = new ArrayList<Food>();


        List<Food> Other_Protein = new ArrayList<Food>();


        List<Food> Snack = new ArrayList<Food>();


        List<Food> Custom = new ArrayList<Food>();


        expandableListDetail.put("Carbohydrate", Carbohydrate);
        expandableListDetail.put("Meat", Meat);
        expandableListDetail.put("SeaFood", SeaFood);
        expandableListDetail.put("Vegetable", Vegetable);
        expandableListDetail.put(" Fruit", Fruit);
        expandableListDetail.put("Other_Protein", Other_Protein);
        expandableListDetail.put("Custom", Custom);
        return expandableListDetail;
    }
    public static HashMap<String, List<Food>> getData() {
        HashMap<String, List<Food>> expandableListDetail;
        expandableListDetail=storeData();
        return expandableListDetail;
    }
}
